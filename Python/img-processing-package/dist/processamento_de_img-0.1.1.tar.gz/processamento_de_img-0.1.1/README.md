# Procesamento de imagens

Decricao :

    Pacote de processamento de imagem versao beta.

        -- Histograma das distribuicao de cores de uma imagem.

        -- Redimencionar a imagem.

        -- Verificar a diferença/similiariedade com outra imagem.

        -- Visualizar.

        -- Ler e salvar. 

    Objetico: Desenvolvida com fins de aprender como criar um package no curso de python da DIO.

## Instalação:

Use o pacote [pip](https://pip.pypa.io/en/stable/) para instalar o processamento_de_img.

```bash
pip install processamento_de_img
```

## Como usar :

Ex.:
``` python
from processamento_de_img.combination import Encontrando_dif

img  = Encontrando_dif(imagem_1,imagem_2)
``` 

## Autor :

Nick: Oibug/Nome:Gubio